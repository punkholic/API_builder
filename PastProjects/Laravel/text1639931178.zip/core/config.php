<?php

class Config
{
  private static $instance = null;
  protected $_config = [];

  public function __construct ()
  {
    $this->_config = [

			"app_name"	=>	"text",
			"mode"	=>	"development",
			"database_name"	=>	"localh",
			"database_username"	=>	"root",
			"database_password"	=>	"",
			"programming-language"	=>	"laravel",

    ];
  }

  /**
   * Get Instance
   *
   * @return mixed
   */
  public static function get_instance()
  {
    if (self::$instance == null)
    {
      self::$instance = new Config ();
    }

    return self::$instance;
  }

  /**
   * Get Connection
   *
   * @return mixed
   */
  public function get_config ()
  {
    return $this->_config;
  }

}